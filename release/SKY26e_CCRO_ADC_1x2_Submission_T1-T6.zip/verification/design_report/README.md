# 詳細設計レポート

## Rev 3　18ページ版の編集と再ビルド

編集元は `report_sections.md`。A4縦のPart 0、Part I–IV、付録の順で18ページを生成する。波形同梱ZIPでは入力図・データ・編集元がそろっており、PDKをインストールせずに組版だけを再現できる。

```sh
python report_source/report18.py --out rebuilt.pdf
```

ReportLab、Pillowと、日本語フォントの標準・太字が必要。WindowsではメイリオTTCを使用する。他の環境は `REPORT_JP_FONT` と `REPORT_JP_BOLD` にTrueTypeのパスを設定する。原寸とSHAの照合には元と同じフォント、ライブラリを使う。ハッシュは同梱のSHA256SUMSにある。

各ページ先頭は `# Part | セクション | 見出し | タグ`、次行は太字の判定文。図表の配置指定はMarkdownのHTMLコメント内に置く。`table` は列幅の比、`verify` は規格・結果・余裕・判定の4列、`fig` は画像名・高さ（pt）・測定条件、`draw` はベクトル回路図の名称・説明を取る。`safe` は赤枠、`note` は青枠。出所記号S/P/G/M/Tは順にSIGN-OFF、PEX-SIM、GATE-SIM、MODEL-EST、SILICON-TBDに展開する。図は全幅または等幅2列、左・右余白各39 pt。表の各行は折返しに応じて伸長する。テキスト枠の下端超過はビルドエラーとなる。

最終版のアナログ波形とT6のデジタル出力を使ってグラフを作成する。提出ZIP内のT1〜T6の実行手順に従い、波形キャッシュを用意する。レイアウト図はKLayout、数値処理はNumPy 2とMatplotlib、PDFはReportLabとPillowで生成する。日本語ゴシックのTrueType系フォントをREPORT_JP_FONT、REPORT_JP_BOLDで指定できる。Windowsの既定フォントはメイリオ。

```sh
klayout -b -r verification/design_report/layout_image.py
python3 verification/design_report/figures.py
python3 verification/design_report/spectra.py
python3 verification/design_report/noise_terms.py
python3 verification/design_report/startup_panel.py
python3 verification/design_report/build_report.py
python3 verification/design_report/package_report.py
```

KLayoutのPythonからPillowを利用する。必要に応じてREPORT_SITEに互換Python環境のsite-packagesを指定する。図の入力はGDS全体およびアナログ抽出波形。キャッシュからのCSV出力は元の時刻点を保存し、同じ時刻の電圧・電流を並べている。T1〜T5の条件は各ケースJSON、T6はシードと時刻を含むクロックごとのゲート出力を参照する。

第3版の実機評価データはレポートZIPの `bench/` にある。展開先で `python3 analysis/spectra.py`、続いて `python3 analysis/noise_terms.py` を実行すると長時間FFTと入力換算雑音表を再計算する。必要なライブラリはNumPyとMatplotlib。電流窓は初回評価用の暫定値で、基板の消費やパッドは別に測る。

電流と配線を再解析するときは提出ZIPのルートで次を実行する。`PDK_ROOT` はsky130Aを含むディレクトリ、`IVERILOG` はIcarus Verilogの実行ファイルを指す。OpenSTAのコンテナは `efabless/openlane:2023.09.07`。電流計算は128 µsの配線後ゲートVCDから1,635ピンの活動を読み、内部・切替・漏れ電力の合計をLiberty供給電圧で割る。

```sh
python3 verification/design_report/current.py
klayout -b -r verification/design_report/route_extent.py
export ADC_FULL=layout/integration/final_analog_c.spice ADC_INTERFACE_CAPS=results/audited/interface_caps.spice
for mode in 2 3; do
    python3 verification/pair.py --mode "$mode" --cm .63 --vd 0 --settle 16 --out "results/design_report/bias_tt_$mode.csv"
done
sed "s|.lib sky130.lib.spice|.lib \"$PDK_ROOT/sky130A/libs.tech/ngspice/sky130.lib.spice\"|" verification/design_report/passives.cir > /tmp/ccro-passives.cir
ngspice -b /tmp/ccro-passives.cir
```

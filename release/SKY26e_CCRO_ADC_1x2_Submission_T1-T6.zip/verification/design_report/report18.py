"""Typeset the page-wise Markdown master and original figures on a fixed A4 grid."""
import argparse
import json
import re
from pathlib import Path
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.lib.utils import ImageReader
from pdf_report import Doc, H, W, INK, TEAL, MUTE, RULE, WHITE, lines, mos, ground, resistor, inv, arrow
from PIL import Image

HERE = Path(__file__).resolve().parent
BUNDLE = (HERE.parent/"figures/gds_tile.png").is_file()
PROJECT = HERE.parents[1]
ASSETS = HERE.parent/"figures" if BUNDLE else PROJECT/"results/design_report/figures"
AUDIT = HERE.parent/"baseline" if BUNDLE else PROJECT/"results"
BLUE, RED = "#28587d", "#993e32"
LEFT, RIGHT = 39, W-39
WIDTH = RIGHT-LEFT
TAGS = {"S":"SIGN-OFF","P":"PEX-SIM","G":"GATE-SIM","M":"MODEL-EST","T":"SILICON-TBD"}
TITLE = "SKY26e 1×2 Tile Differential CCRO-Based ADC — Pre-Silicon Design & Verification Report"

class Report(Doc):
    def __init__(self, path):
        super().__init__(path)
        self.c.setTitle(TITLE)

    def badges(self, right, y, keys):
        for key in reversed(keys.split()):
            name = "["+TAGS[key]+"]"
            width = stringWidth(name,"JB",7.05)+9
            self.rect(right-width,y-8.2,width,12.3,"#eaf1f1",RULE)
            self.txt(right-width+4.5,y+.4,name,7.05,"JB",INK)
            right -= width+4
        return right

    def page(self, part, name, title, keys, takeaway):
        if self.open:self.endpage()
        self.no+=1; self.open=True
        self.c.bookmarkPage("p"+str(self.no));self.c.addOutlineEntry(f"{self.no:02d}  {title}","p"+str(self.no),0)
        self.txt(LEFT,29,part+"  |  "+name,9,"JB",TEAL)
        self.right(RIGHT,29,"tt_um_eleva_ccro_adc / Rev 3",8,"JB",MUTE)
        self.rule(LEFT,38,RIGHT,38)
        self.badges(RIGHT,53,keys)
        title_size=min(21,21*WIDTH/stringWidth(title,"JB",21))
        self.txt(LEFT,83,title,title_size,"JB")
        if self.no==1:
            self.txt(LEFT,105,"— Pre-Silicon Design & Verification Report",14,"JB",TEAL)
        self.y=self.p(LEFT,130 if self.no==1 else 108,takeaway,WIDTH,10.6,16,INK,"JB")+8

    def endpage(self):
        if self.y>797:raise ValueError(f"page {self.no} exceeds text frame: {self.y:.1f}")
        self.rule(LEFT,802,RIGHT,802)
        self.txt(LEFT,819,"SKY26e   /   DIFFERENTIAL CCRO ADC",7.7,"JB",MUTE)
        self.right(RIGHT,819,f"製造前評価   /   {self.no:02d}  ·  18",8,"JB",MUTE)
        self.c.showPage();self.open=False

    def band(self, title, keys):
        self.y+=10
        edge=self.badges(RIGHT,self.y,keys)
        assert LEFT+stringWidth(title,"JB",10.5)<edge-3,(self.no,title)
        self.txt(LEFT,self.y,title,10.5,"JB",TEAL)
        self.rule(LEFT,self.y+6,RIGHT,self.y+6)
        self.y+=12

    def grid(self, title, keys, widths, table):
        self.band(title,keys)
        fractions=list(map(int,widths.split(",")))
        widths=[WIDTH*w/sum(fractions) for w in fractions]
        destinations={"承認レビュー":2,"初日ベンチ":16,"設計・検証":6,"次版・再現":17}
        for idx,row in enumerate(table):
            if len(row)!=len(widths):raise ValueError((self.no,row))
            font="JP" if idx else "JB"
            wrapped=[lines(cell,w-12,font,8.7) for cell,w in zip(row,widths)]
            height=max(map(len,wrapped))*12.15+8
            self.rect(LEFT,self.y,WIDTH,height,INK if not idx else ("#eff4f3" if idx%2 else WHITE))
            x=LEFT
            for items,w in zip(wrapped,widths):
                for j,s in enumerate(items):
                    color=WHITE if not idx else (RED if s.startswith("FAIL") else INK)
                    self.txt(x+6,self.y+12+j*12.15,s,8.7,font,color)
                x+=w
            if self.no==1 and row[0] in destinations:
                self.c.linkRect("","p"+str(destinations[row[0]]),
                                (LEFT,H-self.y-height,RIGHT,H-self.y),relative=0,thickness=0)
            self.y+=height
        self.y+=8

    def note(self,title,body,safety=False):
        color=RED if safety else BLUE
        items=lines(body,WIDTH-24,"JP",9.3)
        height=28+14*len(items)
        self.rect(LEFT,self.y,WIDTH,height,"#fff6f2" if safety else "#f1f6fa",color)
        self.txt(LEFT+10,self.y+15,title,10,"JB",color)
        for j,s in enumerate(items):self.txt(LEFT+10,self.y+32+14*j,s,9.3)
        self.y+=height+9

    def paragraph(self,body):
        self.y=self.p(LEFT,self.y+8,body,WIDTH,9.6,15.4)+5

    def figure(self,title,keys,assets,height,caption):
        self.band(title,keys)
        height=float(height)
        names=assets.split(",")
        col=(WIDTH-12*(len(names)-1))/len(names)
        for i,name in enumerate(names):
            file=ASSETS/(name+".png")
            with Image.open(file) as im: iw,ih=im.size
            factor=min(col/iw,height/ih)
            dw,dh=iw*factor,ih*factor
            self.c.drawImage(ImageReader(str(file)),LEFT+i*(col+12)+(col-dw)/2,H-self.y-(height+dh)/2,dw,dh)
        self.y+=height+11
        self.y=self.p(LEFT,self.y,caption,WIDTH,8.45,12.1,MUTE)+5

    def drawing(self,title,keys,name,caption):
        self.band(title,keys)
        self.c.saveState(); self.c.translate(0,-self.y)
        scale=.95 if name in ("front","reference") else 1
        if scale!=1:
            self.c.translate((1-scale)*W/2,(1-scale)*H)
            self.c.scale(scale,scale)
        height=DRAWINGS[name](self)*scale
        self.c.restoreState(); self.y+=height+11
        self.y=self.p(LEFT,self.y,caption,WIDTH,8.45,12.1,MUTE)+5

    def link(self,title,url):
        self.txt(LEFT,self.y+8,title,8.9,"JB",TEAL)
        self.c.linkURL(url,(LEFT,H-self.y-12,RIGHT,H-self.y+2),relative=0,thickness=0)
        self.y+=19

def front(d):
    for x,gate,node,tail in ((160,"VIN_N","rp","sp"),(437,"VIN_P","rn","sn")):
        d.txt(x-16,10,"VDPWR",8,"JB",TEAL)
        mos(d,x,35,"VB/Gx",True,x==160);d.rule(x,55,x,85,INK)
        d.circle(x,67,2);d.txt(x+5,61,tail,8)
        mos(d,x,105,gate,True,x==160);d.rule(x,125,x,138,INK)
        d.txt(x+6,136,node+" → CCRO",8,"JB")
        d.rule(x,135,x-26,135,INK);d.rule(x-26,135,x-26,144,INK)
        d.rule(x-32,144,x-20,144,INK);d.rule(x-32,148,x-20,148,INK);ground(d,x-26,148)
    d.rule(160,67,205,67,INK);resistor(d,205,67,270);d.rule(270,67,323,67,INK)
    resistor(d,323,67,388);d.rule(388,67,437,67,INK)
    d.circle(296,67,2);d.txt(284,56,"mid",8)
    d.txt(216,88,"39.70 kΩ",8);d.txt(333,88,"39.70 kΩ",8)
    return 163

def reference(d):
    # Same-name electrical nodes connect the feedback gates and each branch.
    for x,pg,ng,node in ((122,"vb","vn","vb"),(234,"vb","vn","vn"),(367,"VGND","vn","kick")):
        d.rule(x,13,x,20,INK);mos(d,x,40,pg,True)
        d.rule(x,60,x,85,INK);d.circle(x,70,2);d.txt(x+6,72,node,8,"JB",TEAL)
        mos(d,x,105,ng,False)
        if x==122:
            d.rule(x,125,x,132,INK);d.txt(x+8,135,"rs",8)
            for k in range(4):
                xx=x+(-3 if k%2 else 3)
                d.rule(x if not k else x+(-3 if (k-1)%2 else 3),132+4*k,xx,136+4*k,INK)
            d.rule(x-3,148,x,151,INK);ground(d,x,151)
        else:ground(d,x,125)
    d.rule(122,13,367,13,TEAL);d.txt(240,9,"VDPWR",8,"JB",TEAL)
    d.txt(471,65,"vb",8,"JB",TEAL);d.rule(479,71,479,85,INK)
    mos(d,479,105,"kick",False);ground(d,479,125)
    d.txt(57,153,"96.21 kΩ",8);d.txt(382,155,"起動検出／vbの引下げ",8)
    return 166

def stage(d):
    for y,src,dst in ((30,"a[k−1]","a[k]"),(107,"b[k−1]","b[k]")):
        d.txt(53,y+3,src,9);d.rule(95,y,131,y,INK);inv(d,131,y,36);d.rule(167,y,222,y,INK);d.txt(228,y+3,dst,9,"JB",TEAL)
    for y,src,dst in ((54,"b[k]","a[k]"),(81,"a[k]","b[k]")):
        d.txt(83,y+3,src,8);d.rule(103,y,131,y,INK);inv(d,131,y,24);d.rule(155,y,180,y,INK);d.txt(188,y+3,dst,8)
    d.rule(291,8,291,127)
    x=411;d.txt(396,9,"rp / rn",8,"JB");mos(d,x,34,"IN",True);mos(d,x,91,"IN",False)
    d.rule(x,54,x,71,INK);d.circle(x,61,2);d.rule(x,61,455,61,INK);d.txt(462,64,"OUT",8,"JB");ground(d,x,111)
    return 131

def cvsl(d):
    d.txt(208,10,"VDPWR",8,"JB",TEAL);d.rule(170,15,299,15,TEAL)
    for x,pg,ng,node in ((170,"R","a[k]","L"),(299,"L","b[k]","R")):
        mos(d,x,35,pg,True,x==170);mos(d,x,100,ng,False,x==170)
        d.rule(x,55,x,80,INK);d.circle(x,64,2);d.txt(x+5,60,node,8,"JB",TEAL);ground(d,x,120)
    for y,node,dest in ((44,"L","tap[k]"),(96,"R","dummy")):
        d.txt(390,y+3,node,9,"JB",TEAL);d.rule(404,y,431,y,INK);inv(d,431,y,25);d.rule(456,y,478,y,INK);d.txt(483,y+3,dest,8)
    return 137

def datapath(d):
    for i,(name,sub) in enumerate((("2-FF 同期","P/N 各15 tap"),("XOR＋計数","dP, dN = 0…15"),("差分＋CIC2","21 bit・2段"),("SPI送信","16 bit・clk/4"))):
        x=LEFT+i*131
        d.rect(x,15,117,48,"#eaf3f3",RULE);d.txt(x+7,35,name,11,"JB");d.txt(x+7,52,sub,8.6)
        if i<3:arrow(d,x+117,39,x+130,39)
    return 79

def cover(d):
    im=ASSETS/"gds_tile.png"
    d.c.drawImage(ImageReader(str(im)),LEFT+12,H-230,158,221.54)
    for i,(val,lab) in enumerate((("15 / 15","公式プリチェック"),("−62.64 dBc","TT・50 kHzのHD3　外部タップ負荷込み"),("62.17 dB","SNDR　雑音モデル中央条件"),("156.25 kS/s","標準出力レート　20 MHz・OSR 128"))):
        y=34+i*55
        d.rule(252,y-22,RIGHT,y-22);d.txt(252,y,val,17,"JB",INK);d.txt(252,y+15,lab,8.8,"JP",MUTE)
    return 237

DRAWINGS={"front":front,"reference":reference,"stage":stage,"cvsl":cvsl,"digital":datapath,"cover":cover}
STANDARDS=["規格値・項目","結果（Sim／照合値）","余裕（Margin）","判定"]

def render(path):
    reg=json.loads((AUDIT/"release_gate.json").read_text())
    master=(HERE/"report_sections.md").read_text(encoding="utf-8")
    for key in ("gds_sha256","analog_pex_sha256"):
        master=master.replace("{{"+key+"}}",reg[key])
    doc=Report(path)
    for page in re.split(r"(?m)^# ",master)[1:]:
        rows=[s.strip() for s in page.splitlines() if s.strip()]
        part,section,title,keys=rows[0].split(" | ")
        doc.page(part,section,title,keys,rows[1].strip("*"))
        i=2
        while i<len(rows):
            line=rows[i];i+=1
            if not line.startswith("<!--"):
                doc.paragraph(line);continue
            cmd,*args=[s.strip() for s in line[4:-3].split("|")]
            if cmd in ("table","verify"):
                table=[]
                while i<len(rows) and rows[i].startswith("|"):
                    row=[v.strip() for v in rows[i].strip("|").split("|")];i+=1
                    if not all(re.fullmatch(r"[-: ]+",v) for v in row):table.append(row)
                if cmd=="verify" and table[0]!=STANDARDS:table.insert(0,STANDARDS)
                doc.grid(args[0],args[1],args[2],table)
            elif cmd=="fig":doc.figure(*args)
            elif cmd=="draw":doc.drawing(*args)
            elif cmd in ("safe","note"):doc.note(args[0],args[1],cmd=="safe")
            elif cmd=="url":doc.link(*args)
            else:raise ValueError(line)
    assert doc.no==18
    doc.done()

if __name__=="__main__":
    cli=argparse.ArgumentParser()
    cli.add_argument("--out",type=Path,default=PROJECT/"output/pdf/SKY26e_CCRO_ADC_Design_Report.pdf" if not BUNDLE else Path("design_report.pdf"))
    render(cli.parse_args().out)

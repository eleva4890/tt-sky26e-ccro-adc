# SKY26e 初回試作の検証手順

提出に使うトップは `tt_um_eleva_ccro_adc`。アナログマクロ、配線済みの読み出しマクロ、34本の外部信号と30本のタップを含む。GitHub Actionsの `gds` ワークフローはSKY26eのcustom GDSアクションで提出用アーティファクトを作り、同じGDSで公式precheckを実行する。GitHubのコミットID、CI実行URL、シャトルの受付番号は各サービスが実行時に発行する。

## レイアウトとサインオフ

LinuxでKLayout、Magic、Netgen、Python 3を使用する。製造検査はSKY130A PDK `6d4d11780c40b20ee63cc98e645307a9bf2b2ab8`。Tiny Tapeoutサポートツールのコミットは `8f7b5060d7f6df73bfd2e0b8d8fa0fd1dca0a0b1`。環境変数 `PDK_ROOT` は `sky130A/` の親、`TT_TOOLS` はこのサポートツールのチェックアウト、`PRECHECK_PYTHON` は公式precheck依存パッケージを備えたPythonを指定する。yowasp-yosysもPATH上に置く。

```bash
bash verification/finalize_tile.sh
bash verification/top_signoff.sh
bash verification/io_drc.sh
bash verification/precheck.sh
bash verification/tt_docs.sh
bash verification/final_analog.sh
bash verification/interface_caps.sh
bash verification/tile_timing.sh
```

`finalize_tile.sh` は同梱の電源・タップ配線済みGDSから外部信号を配線し、ビア金属寸法の調整、バイアス制御2ネットの保護ダイオード、64個のMIM底板の引出し位置変更を適用する。`top_signoff.sh` は外部端子導通、LEF、フラットLVS、アンテナ、タイルI/O集中RCを検証する。LVS比較では同じ2端子素子のSPICE宣言形式をPDKに合わせる。素子数、接続と属性は比較対象に含む。タイミング再検証には同梱した読み出しSPEFと `efabless/openlane:2023.09.07` のOpenSTAを使用する。タイルI/Oは集中RC、デジタル内部は配線後の分布SPEFで表現する。

## 電気性能とパッケージ

ngspiceにはSPICEモデルを収録したSKY130A `8afc8346a57fe1ab7934ba5a6056ea8b43078e71` の `PDK_ROOT` を指定する。`SIM_PYTHON` にNumPy入りのPythonを設定する。Icarus Verilogと標準セルのVerilogモデルをインストールし、必要に応じて `IVL_DIR` を指定する。

```bash
GATE_NETLIST=layout/readout/adc_readout.nl.v bash verification/test.sh > results/readout/final_functional.txt
bash verification/final_performance.sh
python3 verification/release_gate.py
python3 verification/release_report.py
python3 verification/submission.py
```

`results/audited/final_*` は最終アナログマクロからの抽出結果である。基準負荷はタップ当たり5 fF。`final_loaded_*` には、受信側の金属とタップ配線から抽出した対地・相互容量も加えた。タイル外部の電源・基板・パッケージは電気モデルの範囲外。入力段のミスマッチ試験はPDKの `tt_mm` と単体リングf(I)を接続する。SNDRの推定には仮定したリングFoMを使う。これらの適用範囲と合否は[検証判定表](../docs/verification_status.md)に記載した。

提出ZIPを展開したディレクトリでは `sha256sum -c SHA256SUMS` で全ファイルを照合できる。[最終GDS](../gds/tt_um_eleva_ccro_adc.gds)・[LEF](../lef/tt_um_eleva_ccro_adc.lef)

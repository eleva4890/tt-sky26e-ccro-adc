"""Build the Japanese test report and supplement after all cases have completed."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, json, os, re, shutil, sys, tempfile
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from package import write_member
ROOT=Path(__file__).resolve().parents[2]
CASES=[f"T1_{c}_{b}" for c in ("tt","ss","ff","sf","fs") for b in (0,1)]
CASES+=["T2_reference","T2_ramp","T2_brown","T2_leak","T3_clean","T3_dirty","T4_step","T4_ideal","T4_series","T4_literal_ideal","T4_literal_series"]
CASES += [f"T5_{m}_{c}" for m in (0,1) for c in ("removed",0,1,5,20,50)]
CASES+=["T5_tracking","T5_tracking_2ns","T5_hold","T5_hold_mid","T6"]
FILES=["gds/tt_um_eleva_ccro_adc.gds","layout/integration/final_analog_c.spice","results/audited/interface_caps.spice",
       "rtl/adc_readout.v","layout/readout/adc_readout.nl.v","verification/dynamic.py","verification/a0.py",
       "tools/analyze_sndr.py","tools/vco_adc_model.py","results/release_gate.json"]
RELEASE="SKY26e_CCRO_ADC_1x2_Submission.zip"
RELEASE_SHA="eda8de0f78de6de2f11f341491d1ad6799b081cef817115cc4ef22c2271ccfa9"
BASE_MANIFEST_SHA="3c3cf46b87940eb1f1f270695d78d790458dae6b48ae3ef4f564f33f0376d123"
EXTRA_README="\n## 追加検証 T1〜T6\n\n完全同相起動、電源変動、過入力、微小入力ロック、デジタル異常系の判定と試作時の動作制限を収録した。[追加検証結果](docs/torture_T1-T6.md)\n".encode()
EXTRA_PDF="\n仕様表、回路図、最終GDSのレイアウト図、波形と改版課題を収録した。[詳細設計レポート](docs/ccro_adc_design_report.pdf)\n".encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def base_manifest():
    path=ROOT.parent/RELEASE
    if path.exists():
        assert sha(path.read_bytes())==RELEASE_SHA,"release archive changed"
        with ZipFile(path) as z: manifest=z.read("SHA256SUMS")
    else: manifest=(ROOT/"results/torture/original_submission.sha256").read_bytes()
    assert sha(manifest)==BASE_MANIFEST_SHA
    return manifest
def base_files():
    hashes={line[66:]:line[:64] for line in base_manifest().decode().splitlines()}
    members={}
    for name,expected in hashes.items():
        b=(ROOT/name).read_bytes()
        if name=="README.md":b=b.removesuffix(EXTRA_PDF).removesuffix(EXTRA_README)
        assert sha(b)==expected,name
        members[name]=b
    return members
def verify_input():
    base=base_files()
    return {name:sha(base[name]) for name in FILES}
def supply_budget(data):
    """Apply measured disturbance power to the specified 54-dB reference."""
    import numpy as np
    def paired(a,b):
        x,y=[np.asarray(record,dtype=float) for record in (a,b)]
        # Identical sample times. Remove DC and the coherent input tone. Double-sided
        # weights are common to interior bins; Nyquist has half their weight.
        ratio=np.abs(np.fft.rfft(y-x))**2
        ratio[[0,2]]=0
        ratio[-1]*=.5
        r=float(np.sum(ratio)/abs(np.fft.rfft(y)[2])**2)
        drop=float(10*np.log10(1+r*10**5.4))
        return dict(difference_to_tone_power_ratio=r,loss_from_54_dB=drop,projected_sndr_dB=54-drop)
    c,n=data["T3_clean"],data["T3_dirty"]
    phases=[]
    for a,b in zip(c["sample_phase_sweep"],n["sample_phase_sweep"],strict=True):
        assert a["offset_ns"]==b["offset_ns"]
        phases.append(dict(offset_ns=a["offset_ns"],quiet_dB=a["sndr_dB"],injected_dB=b["sndr_dB"],
                           quiet_to_injected_loss_dB=a["sndr_dB"]-b["sndr_dB"],**paired(a["codes"],b["codes"])))
    gate=data["T3_gate"]
    actual=dict(quiet_dB=gate["clean_sndr_dB"],injected_dB=gate["dirty_sndr_dB"],
        quiet_to_injected_loss_dB=gate["clean_sndr_dB"]-gate["dirty_sndr_dB"],**paired(gate["clean_codes"],gate["dirty_codes"]))
    all_pairs=[*phases,actual]
    return dict(target_dB=54,maximum_allowed_loss_dB=3,bins_excluded=[0,2],records_per_condition=16,
        reference_assumption="Disturbance in paired code differences adds in power to the nominal 54-dB noise and distortion budget.",
        phases=phases,routed_gate=actual,max_loss_from_target_dB=max(p["loss_from_54_dB"] for p in all_pairs),
        max_loss_from_measured_quiet_dB=max(p["quiet_to_injected_loss_dB"] for p in all_pairs),
        min_measured_injected_dB=min(p["injected_dB"] for p in all_pairs))
def report(data):
    yes=lambda s:"合格" if s else "未達"
    t1=[data[c] for c in CASES if c.startswith("T1_")]
    t1ok=sum(v["status"]=="PASS" for v in t1)
    ref,ramp,brown,leak=[data["T2_"+s] for s in ("reference","ramp","brown","leak")]
    fast,slow=ref["tail"],ramp["tail"]
    err=max(abs(slow[k]/fast[k]-1) for k in ("fp_MHz","fn_MHz","vb_V"))
    ramp_ok=err<=.05 and slow["min_tap_MHz"]>0 and slow["min_swing_V"]>1.5
    t2ok=ramp_ok and brown["status"]==leak["status"]=="PASS"
    clean,dirty=data["T3_clean"],data["T3_dirty"]
    decrease=clean["sndr_dB"]-dirty["sndr_dB"]
    slip=min(v["min_excursion_cycles"] for v in dirty["lock_excursion"].values())
    phase_pairs=list(zip(clean["sample_phase_sweep"],dirty["sample_phase_sweep"],strict=True))
    min_dirty=min(b["sndr_dB"] for a,b in phase_pairs)
    worst_drop=max(a["sndr_dB"]-b["sndr_dB"] for a,b in phase_pairs)
    gate=data["T3_gate"]
    budget=data["T3_budget"]
    t3ok=budget["min_measured_injected_dB"]>=51 and budget["max_loss_from_target_dB"]<3 and slip>1
    step,ideal,series=[data["T4_"+s] for s in ("step","ideal","series")]
    hd0,hd1=ideal["hd3_dBc"],series["hd3_dBc"]
    lh0,lh1=[data["T4_literal_"+s]["hd3_dBc"] for s in ("ideal","series")]
    t4ok=step["status"]=="PASS" and max(hd1-hd0,lh1-lh0)<1
    t5=[data[c] for c in CASES if c.startswith(("T5_0_","T5_1_"))]
    d0=data["T5_0_0"]
    v=data["T6"];r=v["rtl"];g=v["gates"]
    def maximum(rows,key):return max(x[key] for x in rows)
    t6ok=all(a[k] for a in (r,g) for k in ("reset_pass","bubble_pass","mode_pass")) and r["internal_acc1_difference_after_last_burst"]==0
    hold=data["T5_hold"]
    tracking=data["T5_tracking"]
    wraps=["観測なし" if k is None else f"tick {k}" for k in gate["first_wrap_flag_tick"]]
    t5out="未達" if any(s["lock_indicator"] for s in (d0,hold,tracking,data["T5_tracking_2ns"])) else "5倍余裕の立証に至らず"
    t3out=yes(t3ok)+"（有限窓）"
    if t3ok and budget["max_loss_from_measured_quiet_dB"]>3:
        t3out="条件付き（54 dB基準合格、対照比3 dB超）"
    summary={"T1":yes(t1ok==10),"T2":yes(t2ok),"T3":t3out,"T4":yes(t4ok),"T5":t5out,"T6":yes(t6ok)}
    text=["# SKY26e CCRO ADC　T1〜T6 追加検証","",
    "提出候補の最終GDSから抽出したアナログ回路と配線後ゲートを評価した。以下の合否は今回指定された試験条件に対するもの。","",
    "| 試験 | 判定 | 主な観測値 |","|---|---|---|",
    f"| T1　完全同相からの起動 | {summary['T1']} | 左右各15段とも規定を満たした条件 {t1ok}/10 |",
    f"| T2　電源復帰・リーク | {summary['T2']} | 10 msランプ {yes(ramp_ok)}、ブラウンアウト {yes(brown['status']=='PASS')}、39単位のOFFリーク {yes(leak['status']=='PASS')} |",
    f"| T3　電源電流注入 | {summary['T3']} | 配線後ゲートのSPIから復号した16点のSNDRが {gate['clean_sndr_dB']:.2f} → {gate['dirty_sndr_dB']:.2f} dB |",
    f"| T4　過入力・入力負荷 | {summary['T4']} | 定格復帰 {yes(step['status']=='PASS')}、1.5 kΩによるHD3の変化 {hd1-hd0:+.2f} dB |",
    f"| T5　微小入力ロック | {summary['T5']} | 実装の直接結合4.1989 fF、零入力起動後の+1 mVで位相変動 {hold['relative_phase_span_cycles']:.4f} 周期／160 µs。線形域予想1.104周期 |",
    f"| T6　バブル・リセット・設定 | {summary['T6']} | {r['frames']}フレームで形式異常 {r['malformed_count']} 件、OSR変更後の最長完了時間 {maximum(r['mode_changes'],'spi_complete_clocks')}クロック |",
    "","## T1　同相初期値から逆相に移るまで","",
    "各リングの全30内部ノード、左右合計60ノードを0.35 Vにそろえ、1.8 Vの定電源、27 °C、差動入力0 Vで開放した。外部キックなし。各段の2波形が振幅条件（リング電源の20%以下から80%以上）と180°±15°を満たし、周期が最終周期の±15%に収まる状態が以後続くことを確認した。最初の連続2周期の終了時刻を起点から数え、10周期以内かを判定した。","",
    "| コーナー | BIAS_SEL | 実測初期差・設定誤差の最大値（V） | 合格段数／30 | 最遅確認（周期） | 最終周期の最大位相誤差 | 判定 |","|---|---|---:|---:|---:|---:|---|"]
    for a in t1:
        name,c,b=a["case"].split("_")
        stages=[z for x in a["banks"].values() for z in x["stages"]]
        lat=[s["confirmed_cycles"] for s in stages if s.get("confirmed_cycles") is not None]
        latest=f"{max(lat):.2f}" if lat else "—"
        angles=[abs(s["final_phase_deg"]-180) for s in stages if s.get("final_phase_deg",-999)>=0]
        phase_error=f"{max(angles):.2f}°" if angles else "—"
        text.append(f"| {c.upper()} | {int(b):02b} | {max(v['ic_error_V'] for v in a['banks'].values()):.2e} | {sum(s['pass_stage'] for s in stages)} | {latest} | {phase_error} | {a['status']} |")
    text+=["","対象は幅比1/5の抽出回路。実際の寄生非対称を含む。初期電圧値、ランダムミスマッチ、電源ランプを組み合わせた起動歩留まりはこの10条件の対象外。","",
    "## T2　電源ランプ・瞬断・リーク","",
    "| 電源試験 | P側周波数 | N側周波数 | バイアス電圧 | 30タップ最小振幅 |","|---|---:|---:|---:|---:|"]
    for name,vv in [("1 µsランプ、低速基準",fast),("10 msランプ、低速",slow),("瞬断前、標準",brown["before"]),("0.6 V保持中",brown["during"]),("電源再投入後、標準",brown["after"])]:
        text.append(f"| {name} | {vv['fp_MHz']:.5f} MHz | {vv['fn_MHz']:.5f} MHz | {vv['vb_V']:.5f} V | {vv['min_swing_V']:.3f} Vpp |")
    text += ["",f"低速BIAS_SEL=01はTT・27 °Cで0→1.8 Vを10 msかけて印加した。最終80 µsにおける左右周波数・バイアスの基準との差は最大 {100*err:.3f}%。ブラウンアウトは標準BIAS_SEL=00で0.6 Vを50 µs保持し、10 nsで1.8 Vに復帰させた。電源の両試験とも、全タップが1.5 Vppを超え、基準からの周波数・バイアスの差が5%以内なら合格とした。","",
    "| FF・85 °C・1.98 V、低速バイアス | OFF39単位の正味電流 | ON1単位の正味電流 | 実ON電流比 |","|---|---:|---:|---:|"]
    for s,a in leak["banks"].items():text.append(f"| {s.upper()} | {a['off_nA']:.3f} nA | {a['on_nA']:.2f} nA | {a['off_percent_actual']:.3f}% |")
    if "numerical_cross_check" in ramp:
        proof=ramp["numerical_cross_check"]
        text+=["",f"10 msランプは全抽出素子を保ち、連続時間の過渡を0〜10.1 msまで最大50 ns刻み、reltol=0.003で積分した。1 µsランプの対照でreltol=0.0005の基準と独立に比較し、周波数・バイアス・振幅の相対差は最大 {100*max(proof['reference_relative_differences'].values()):.3f}%（採用上限1%）。局所電源と指定したランプ軌跡の最大差は {proof['trajectory_error_V']:.2g} V。"]
    text+=["","出力端子にゼロ電圧電流計を挿入し、左右それぞれの全39個を直接合算した。各側の整数発振周期で符号付き時間平均を取り、その絶対値をリークとして評価した。電流絶対値の平均もJSONに収録した。判定上限は25 nAおよび実ON電流の5%。","",
    "## T3　電源由来の変調","",
    f"電源・接地に各5 Ω＋2 nHを置き、20 MHzと156.25 kHzの各1 mA矩形波を同時に注入した。20 MHz標本化、OSR 128、19.53125 kHz・−1 dBFSの差動入力。局所電源の振幅は対照 {clean['local_supply_pp_mV']:.2f} mVpp、注入時 {dirty['local_supply_pp_mV']:.2f} mVpp。30タップを標本化してCICを通した16コードのコヒーレントFFTで、SNDRの悪化量は {decrease:+.2f} dB。許容値は3 dB、注入後の下限は51 dB。","",
    f"上記は標本化位相25 nsの値。SSN注入との相対位相を0〜43.75 ns、6.25 ns刻みの8通りで再標本化した。注入時の最小SNDRは {min_dirty:.2f} dB、同一位相の対照からの最大低下は {worst_drop:.2f} dB。","",
    f"指定の54 dB目標に対する悪化量は、同じタイミングの注入・対照コードの差から求めた。16点FFTのDCと入力基本波を除いた差の電力を注入時基本波で正規化し、これを54 dBの基準雑音に電力加算する仮定で算出した。8位相と配線後ゲートを合わせて最大 {budget['max_loss_from_target_dB']:.3f} dB（許容3 dB）。仮定した雑音を加算せず、観測した2回のSNDRを直接比較した場合の最大低下は {budget['max_loss_from_measured_quiet_dB']:.3f} dB。","",
    f"配線後ゲートにも両条件の30タップを同じ20 MHzで再生した。リセット時刻とCICの間引き位置を含む実フレームのSPIから、対照 {gate['clean_sndr_dB']:.2f} dB、注入 {gate['dirty_sndr_dB']:.2f} dBを得た。各 {gate['checked_clocks']} クロックで数値オラクルとのSPI不一致は0件。","",
    f"WRAP_ERRを初めて観測したクロックは対照 {wraps[0]}、注入 {wraps[1]}。tick 512以降の片側15タップの最大遷移数は対照 {gate['max_transition_count_after_tick_512'][0]}、注入 {gate['max_transition_count_after_tick_512'][1]}（警告の閾値14）。","",
    "| 差周波の変調成分 | 対照 | 電流注入 | 注入時の基本波比 |","|---|---:|---:|---:|---:|"]
    for k,amp in dirty["freqline_amplitude_Hz"].items():text.append(f"| {float(k):g} MHz | {clean['freqline_amplitude_Hz'][k]:.1f} Hz | {amp:.1f} Hz | {dirty['freqline_dBc'][k]:.2f} dBc |")
    text+=["",f"両リングについて、20 MHzの1/4〜1/8と156.25 kHzの16〜33倍に対し相対位相を追跡した。102.4 µs窓で最も位相差の変化が小さかった候補でも {slip:.2f} 周期。1周期を超えれば、その比に全窓で連続同期する挙動を棄却する。短時間の引き込み、他の分数比、素子雑音を含む実効SNDRはこの測定からは確定できない。周波数変調の各行は元の帯域で抽出した振幅、SNDRはデシメーション後の値。","",
    "## T4　過入力・コモンモード・入力スイッチ","",
    f"差動入力を+0.6→+0.1 V、−0.6→−0.1 Vとし、定格に戻してから全タップが定常周期の±5%に入るまでを測った。正負で最も遅いタップはそれぞれ {step['recovery_cycles'][0]:.2f}、{step['recovery_cycles'][1]:.2f} 周期。「すぐに」の判定値を2周期に設定した。","",
    "| 定常観測区間 | P側（MHz） | N側（MHz） | 30タップ最小（Vpp） |","|---|---:|---:|---:|"]
    for label,vv in zip(["+0.6 V","+0.1 Vへ復帰","−0.6 V","−0.1 Vへ復帰","Vcm 0.48 V","Vcm 0.78 V","Vcm 0.63 Vへ復帰"],step["windows"]):
        text.append(f"| {label} | {vv['fp_MHz']:.4f} | {vv['fn_MHz']:.4f} | {vv['min_swing_V']:.3f} |")
    text+=["",f"入力スイッチは各入力の直列抵抗とピンから接地への10 pFで近似した。TT・27 °C・50 kHz、差動±0.20 Vで、左右周波数差のHD3は0 Ωで {hd0:.3f} dBc、1.5 kΩで {hd1:.3f} dBc。抵抗寄与は {hd1-hd0:+.3f} dB（規定1 dB未満）、1.5 kΩ時の絶対値は−62 dBc規格に対して {(-62-hd1):+.3f} dBの余裕。スイッチ抵抗の電圧依存性はこの固定RC近似の対象外。","",
    f"10 pFも信号経路へ直列に置く条件を別途実行した。コンデンサでDCが遮断されるため、各ピンに100 MΩで0.63 Vのバイアス帰路を与えた。0 Ωで {lh0:.3f} dBc、1.5 kΩで {lh1:.3f} dBc、悪化量 {lh1-lh0:+.3f} dB。","",
    "## T5　左右リング間の結合と1 mV入力","",
    "表の結合容量は各リングの電源ノード間のもの。実装はCmidなし、直接結合4.1989 fF。比較用に中点と接地の間に10 × 10 µmのPDK MIMを追加した。各ケースで差動入力を+1 mVとし、13〜25 µsの12 µs全体と前後半を評価した。通常の感度6.9 kHz/mVの10%未満の差が3窓とも続く場合を「ロック相当」とした。別途30位相から左右の相対位相を復元した。","",
    "| 直接結合の変更 | 合計 fF | Cmidなし　差 kHz | Cmidあり　差 kHz | ロック相当（なし／あり） |","|---|---:|---:|---:|---|"]
    for c in ("removed",0,1,5,20,50):
        a,b=data["T5_0_"+str(c)],data["T5_1_"+str(c)]
        label="抽出コンデンサ除去（原因切分け）" if c=="removed" else f"+{c} fF"
        text.append(f"| {label} | {a['total_direct_fF']:.4f} | {a['phase_fit_kHz']:+.4f} | {b['phase_fit_kHz']:+.4f} | {'あり' if a['lock_indicator'] else 'なし'}／{'あり' if b['lock_indicator'] else 'なし'} |")
    mid0=data["T5_1_0"]
    if d0["lock_indicator"] and not mid0["lock_indicator"]:
        mid_note="直接結合を実装値に固定し中点MIMだけを追加すると、差周波はロック相当の判定範囲を外れた。この観測窓では中点容量による改善が見られた。"
    elif not d0["lock_indicator"] and not mid0["lock_indicator"]:
        mid_note="実装値の直接結合では中点MIMの有無の両方で差周波が生じた。この組合せだけからソース経由ロックの抑圧効果は立証できない。"
    else:
        mid_note="実装値の直接結合では中点MIM追加後もロック相当であり、ソース経由ロックの抑圧効果は確認できなかった。"
    text+=["",mid_note,"","5倍余裕に必要な直接結合は20.9945 fF。"]
    if d0["lock_indicator"]:
        text[-1]+="実装条件の追加0 fFで既に微小信号応答が抑えられ、増量方向でアンロックからロックへ移る臨界点を特定できなかった。5倍余裕は未達。"
    else:text[-1]+="離散容量と有限観測窓からは連続する臨界容量を特定できない。"
    for i,mid_label in [(0,"実装"),(1,"中点MIM追加")]:
        sweep=sorted([x for x in t5 if x["mid_side_um"]==10*i],key=lambda x:x["total_direct_fF"])
        first=next((j for j,x in enumerate(sweep) if x["lock_indicator"]),None)
        if first==0:
            text.append(mid_label+"では直接結合を0 fFにした感度試験でもロック相当になった。直接結合だけで説明できる正の臨界容量は求められない。")
        elif first is not None:
            low,high=sweep[first-1]["total_direct_fF"],sweep[first]["total_direct_fF"]
            text.append(f"{mid_label}で最初にロック相当へ移った観測点は、直接結合 {low:.4f} fF超〜{high:.4f} fF以下の区間。対応する抽出容量比は {low/4.1989:.2f}〜{high/4.1989:.2f} 倍。")
        else:
            text.append(f"{mid_label}では試験した最大の直接結合 {sweep[-1]['total_direct_fF']:.4f} fFまでロック相当は観測されなかった。")
    text+=["",f"起動時から+1 mVを与える掃引に加え、実装回路を零入力で起動し、12 µsで+1 mVへ切り替えた。18〜178 µsでの位相回帰は {hold['delta_kHz']:+.3f} kHz、相対位相の変動幅は {hold['relative_phase_span_cycles']:.4f} 周期。線形域の感度なら同じ160 µsに {hold['nominal_free_beat_cycles']:.3f} 周期進む。こちらのロック相当判定は{'あり' if hold['lock_indicator'] else 'なし'}。同一GDSの既存A6では電源に追従して差動入力を立ち上げ、+1 mVで+1.17 Hzを観測した。初期状態と観測窓を明記して解釈する。"]
    text+=["",f"投入時から+1 mVとする条件と同一のデッキ・最大刻み3 nsで、差動源だけを電源追従の0→1 mVに替えると {tracking['phase_fit_kHz']:+.3f} kHzだった。既存A6には最大刻み2 nsや線形制御源との違いもあり、旧結果との違いを入力履歴だけには帰属できない。"]
    t2ns=data["T5_tracking_2ns"]
    held_mid=data["T5_hold_mid"]
    text+=["",f"零入力起動の同じ長窓試験で中点MIMだけを206.58 fF追加すると、位相回帰 {held_mid['delta_kHz']:+.4f} kHz、位相変動 {held_mid['relative_phase_span_cycles']:.4f} 周期、ロック相当判定は{'あり' if held_mid['lock_indicator'] else 'なし'}。この比較は他の直接結合と刺激を維持した。"]
    if hold["lock_indicator"]:
        text.append("製造候補の4.1989 fFでは零入力からの履歴でロック相当となった。短窓で追加容量を増やしてもロックが見えない結果と合わせ、初期条件に依存しない5倍余裕は未達と判定する。")
    text+=["",f"電源追従条件をそのままにして過渡解析の指定刻みと上限を3 nsから2 nsにすると、30位相による回帰値は {tracking['phase_fit_kHz']:+.5f} → {t2ns['phase_fit_kHz']:+.5f} kHz、P0・N0の立上り間隔による差は {tracking['delta_kHz']:+.5f} → {t2ns['delta_kHz']:+.5f} kHzだった。モデル、負荷、入力波形、解析窓、許容誤差は同一である。"]
    if tracking["lock_indicator"]!=t2ns["lock_indicator"]:
        text.append("解析刻みだけでロック相当の判定が反転した。3 nsでの短窓容量掃引から、物理的な臨界容量の下限を保証することはできない。実機での周波数差も数値解析のいずれか一方の値に固定しない。")
    text+=["","## T6　バブル・リセット解除・動作中切替","",
    f"20 MHzで{r['ticks']:,}クロックを、RTLと配線後ゲートで各1回実行した。順序を持つ15タップ列の境界付近に1クロック幅のバブルを{r['bubble_count']}回挿入し、入力の各遷移数から独立に三角重みで計算したCIC2出力とSPIを全クロック照合した。乱数seedは{v['seed']}。DBG_MODEは{r['dbg_transitions']}回変更した。","",
    f"両実装のSPI照合不一致はRTL {r['oracle_mismatched_ticks']}、ゲート {g['oracle_mismatched_ticks']}クロック。バブルで{r['different_frame_words']}フレームのコードが変化し、影響範囲を過ぎた後の不一致は{len(r['persistent_bad_frames'])}件。最後の単独バブルで第1積分器の差は {r['directed_acc1_difference']['7379']}→{r['directed_acc1_difference']['7399']}カウントとなり、400クロック後も {r['directed_acc1_difference']['7780']}カウントだった。この内部差は21 bit剰余演算での単発エラーの応答である。初期の試験指定には内部差の残留禁止も含まれたが、2段差分後は正しいコードに戻り、単発バブルのための再初期化は不要。OSR切替の期限超過は独立した未達事項である。","",
    f"第2積分器の差もtick 7399の {r['directed_acc2_difference']['7399']} からtick 7780の {r['directed_acc2_difference']['7780']} に進み、381クロックで+762カウントだった。2段差分の後ではこの一次傾斜が消えた。","",
    "| 操作 | 回数 | 新設定の最初のCS開始までの最長 | 16 bit受信完了までの最長 | 許容 |","|---|---:|---:|---:|---:|"]
    for name,rows0 in [("リセット解除",r["reset_events"]),("OSR切替",r["mode_changes"])]:
        for osr in (128,256):
            rows=[x for x in rows0 if x["osr"]==osr]
            if rows:text.append(f"| {name}、OSR {osr} | {len(rows)} | {maximum(rows,'spi_start_clocks')} clk | {maximum(rows,'spi_complete_clocks')} clk | {2*osr} clk |")
    text+=["","CSロー64クロック、SCLK立上り間隔4クロック、1フレーム16ビットを照合した。リセットは各回クロック立上り1 ps前に解除した。RTL・機能ゲートモデルでは実フリップフロップのメタステーブル持続時間を測れない。現行RTLは旧フレームが有効な状態でphase=97を待ってOSRを採用するため、256→128切替の期限を超える場合がある。初回試作ではOSRをリセット中に設定して変換中は固定する運用が可能。","",
    "## 再現と設計の同一性","",
    "追加検証を含む提出ZIPには設計ソース、測定値、SPICEデッキ、再現手順と入力ハッシュを収録した。PDKとEDAツールは別途用意する。バイナリ波形のハッシュは各ケースに収録した。アナログ計算は抽出素子・容量、トップ配線のタップ間容量、入力ごとの受信負荷5 fFを使用した。電源・グラウンド以外の配線分布抵抗、確率的素子雑音は含まない。","",
    f"追加試験前の基準ZIPのSHA-256は `{RELEASE_SHA}`。GDS、抽出SPICE、RTL、配線後ネットリスト、および比較基準が同ZIP内のファイルとバイト単位で一致することを確認した。追加後の提出ZIPには、収録ファイルごとのSHA-256をSHA256SUMSに記録した。",""]
    return "\n".join(text),summary
def main():
    checks=verify_input()
    out=ROOT/"results/torture"
    missing=[c for c in CASES if not (out/(c+".json")).is_file()]
    if missing:raise SystemExit("Missing cases: "+" ".join(missing))
    data={c:json.loads((out/(c+".json")).read_text()) for c in CASES}
    for c in CASES[:-1]:
        assert data[c]["pex_sha256"]==checks["layout/integration/final_analog_c.spice"],c
    gate=out/"T3_gate.json"
    if not gate.is_file() or any(json.loads(gate.read_text())["input_sha256"][c]!=data[c]["raw_sha256"] for c in ("T3_clean","T3_dirty")):
        from t3_gate import main as replay
        replay()
    data["T3_gate"]=json.loads(gate.read_text())
    budget=out/"T3_power_budget.json"
    data["T3_budget"]=supply_budget(data)
    budget.write_text(json.dumps(data["T3_budget"],indent=2,allow_nan=False)+"\n")
    txt,summary=report(data)
    md=ROOT/"docs/torture_T1-T6.md";md.write_text(txt,encoding="utf-8")
    man=out/"manifest.json"
    numerical=json.loads(man.read_text(encoding="utf-8")).get("simulation_inputs",{}) if man.exists() else {}
    if os.environ.get("PDK_ROOT"):
        pdk=(Path(os.environ["PDK_ROOT"])/"sky130A").resolve()
        rev=re.search(r"/versions/([0-9a-f]{40})/",pdk.as_posix()+"/")
        numerical={"pdk_release":rev[1] if rev else pdk.as_posix(),"files":{}}
        for name in ("libs.tech/ngspice/sky130.lib.spice","libs.tech/ngspice/spinit",
                     "libs.tech/ngspice/r+c/res_typical__cap_typical__lin.spice","libs.ref/sky130_fd_pr/spice/sky130_fd_pr__cap_mim_m3_1.model.spice",
                     "libs.ref/sky130_fd_sc_hd/verilog/sky130_fd_sc_hd.v","libs.ref/sky130_fd_sc_hd/verilog/primitives.v"):
            numerical["files"][name]=sha((pdk/name).read_bytes())
        iv=Path(os.environ.get("IVERILOG","/tmp/sky26e-ccro-tools/usr/bin/iverilog"))
        for name,path in (("ngspice",shutil.which("ngspice")),("iverilog",iv),("vvp",iv.parent/"vvp")):
            if path and Path(path).is_file():numerical["files"][name]=sha(Path(path).read_bytes())
    man.write_text(json.dumps(dict(release_sha256=RELEASE_SHA,input_sha256=checks,simulation_inputs=numerical,results=summary,case_count=len(CASES),additional_gate_replays=1),indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    files=[md,man,gate,budget,*[out/(c+".json") for c in CASES],*[p for p in Path(__file__).parent.iterdir() if p.suffix in (".py",".v",".md",".sh")]]
    work=Path(os.environ.get("TORTURE_WORK","/tmp/ccro-torture-v1"))
    origins={c:data[c].get("measured_case",c) for c in CASES if c!="T6"}
    decks={f"decks/{c}/test.cir":(work/origins[c]/"test.cir").read_bytes() for c in CASES if c!="T6"}
    # Keep a single copy of each distinct core and identify it from every deck.
    index={}
    for c in CASES[:-1]:
        core=(work/origins[c]/"core.spice").read_bytes()
        name="decks/cores/"+sha(core)+".spice"
        decks[name]=core
        index[c]={"core_spice":name,"stimulus_sha256":sha(decks[f"decks/{c}/test.cir"]),
                  "binary_waveform_sha256":data[c]["raw_sha256"],"points":data[c]["stored_points"]}
    decks["decks/index.json"]=(json.dumps(index,indent=2)+"\n").encode()
    members=base_files()
    members["README.md"]+=EXTRA_README
    pdf=ROOT/"output/pdf/SKY26e_CCRO_ADC_Design_Report.pdf"
    if not pdf.exists():pdf=ROOT/"docs/ccro_adc_design_report.pdf"
    if pdf.exists():
        members["docs/ccro_adc_design_report.pdf"]=pdf.read_bytes()
        members["README.md"]+=EXTRA_PDF
    members["results/torture/original_submission.sha256"]=base_manifest()
    members.update({p.relative_to(ROOT).as_posix():p.read_bytes() for p in files})
    design=ROOT/"verification/design_report"
    members.update({p.relative_to(ROOT).as_posix():p.read_bytes() for p in design.iterdir() if p.suffix in (".py",".md",".tcl",".v",".cir")})
    for name in ("noise_terms.json","passives.txt","digital_current.csv","bias_tt_2.csv","bias_tt_3.csv","route_extent.json"):
        path=ROOT/"results/design_report"/name
        members[path.relative_to(ROOT).as_posix()]=path.read_bytes()
    members.update(decks)
    if "numerical_cross_check" in data["T2_ramp"]:
        for extra in ("T2_reference_alt","T2_ramp_alt"):
            f=out/(extra+".json")
            members[f.relative_to(ROOT).as_posix()]=f.read_bytes()
            members[f"decks/{extra}/test.cir"]=(work/extra/"test.cir").read_bytes()
    members["SHA256SUMS"]="".join(f"{sha(b)}  {name}\n" for name,b in sorted(members.items())).encode()
    archive=ROOT.parent/"SKY26e_CCRO_ADC_1x2_Submission_T1-T6.zip"
    with tempfile.NamedTemporaryFile(dir=archive.parent,suffix=".zip",delete=False) as f:tmp=Path(f.name)
    try:
        with ZipFile(tmp,"w",ZIP_DEFLATED) as z:
            for name,b in sorted(members.items()):write_member(z,name,b)
        with ZipFile(tmp) as z:
            assert z.testzip() is None and len(z.namelist())==len(members)
            for name,b in members.items():assert z.read(name)==b
        tmp.replace(archive)
    finally:tmp.unlink(missing_ok=True)
    print(sha(archive.read_bytes()),archive.name,summary)
if __name__=="__main__":main()

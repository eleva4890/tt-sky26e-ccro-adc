# T1〜T6の再現

SKY26e_CCRO_ADC_1x2_Submission_T1-T6.zip を作業用ディレクトリに展開する。そのディレクトリで `sha256sum -c SHA256SUMS` により全収録ファイルを照合し、次のコマンドを実行する。

```sh
export PDK_ROOT=/path/to/pdk_root
export IVERILOG=/usr/bin/iverilog
export IVERILOG_BASE=/usr/lib/x86_64-linux-gnu/ivl
export TORTURE_WORK=/path/to/writable/simulation-cache
python3 verification/torture/run_all.py --jobs 4
```

使用したのは Linux、ngspice 42、Python 3.12、NumPy 2、Icarus Verilog、SKY130A ngspiceモデル 8afc8346a57fe1ab7934ba5a6056ea8b43078e71。PDK_ROOT 直下の sky130A からデバイスモデル、spinit、標準セル機能モデルを参照する。Icarus Verilog と vvp は同じディレクトリを使用する。並列数は使用可能なメモリとCPUに合わせて設定する。

個別に実行する場合は、たとえば `python3 verification/torture/bench.py T1_tt_0 T1_tt_1` または `python3 verification/torture/t6.py` を使う。各アナログケースについて、キャッシュに test.cir、core.spice、run.log、waves.raw、completed.json を保存する。入力デッキのハッシュと終了時刻を検査した後、保存済み波形から再採点できる。PDKやngspiceのバージョンを変えるときは別のキャッシュを指定する。

判定表は docs/torture_T1-T6.md、各条件の数値は results/torture にある。各JSONの MEASURED はペア比較前の数値取得を示す。上位判定は manifest.json を参照する。T1の電圧・許容位相・確認周期、T2の復帰判定窓、T3のFFT点数と周波数比、T4の外部RC接続、T5の人工容量、T6のフレーム起点・完了時刻は報告書に記載した。

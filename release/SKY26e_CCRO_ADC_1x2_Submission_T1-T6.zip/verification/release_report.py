"""Write the release report from audited numeric evidence after the release gate passes."""
from release_gate import audit, rows, ROOT, A

def main():
    d=audit()
    m=rows(A/"front_mismatch.csv")
    offsets=[float(r["offset_mV"]) for r in m]
    caps=[float(r["external_metal_C_fF"]) for r in rows(A/"interface_caps.csv")]
    measured=d["loaded_diff_kHz_by_mV"]
    h=d["static_dynamic_delta_dB"]
    zero=next(r for r in rows(A/"final_small.csv") if float(r["diff_V"])==0)
    loaded={int(r["harmonic"]):float(r["relative_dBc"]) for r in rows(A/"final_loaded_dynamic.csv")}
    slow=rows(A/"final_slow.csv")[0]
    extra=rows(A/"final_loaded_fast.csv")[0]
    budget=d["noise_budget_range_dB"]
    code=d["mixed_frame_codes"]
    body=f"""# SKY26e 差動VCOベースADC　初回試作の提出判定

**判定　ローカル提出検証合格。** 対象は `tt_um_eleva_ccro_adc`、SKY130A、1×2タイル、161.00 × 225.76 µm、アナログ入力2本。GDSのSHA-256は `{d['gds_sha256']}`。この文書は製造前シミュレーションとローカルサインオフを記録する。シャトル事務局による受付とシリコン測定は別工程である。

## 製造・デジタル検証

| 検査 | 最終結果 |
|---|---|
| 公式precheck、MagicフルDRC | 15/15合格。Magic違反0、KLayout BEOL違反0。全53端子の位置と外形を照合し、met5は未使用。[precheck](../results/top_precheck.md)・[フルDRC](../results/top_drc.txt) |
| トップLVS・アンテナ | Netgenで{d['devices']:,}素子、{d['nets']:,}ネットが一意に一致。Magicアンテナ違反0。[LVS](../results/top_lvs.txt)・[アンテナ](../results/top_antenna.txt) |
| 配線導通 | タイルの外部34信号と30本の位相タップが64/64導通、外部端子間の短絡0。[導通](../results/top_connectivity.txt) |
| タイミング | 32 MHz、配線後デジタルSPEF、最終タイルの集中RCと隣接配線の逆相切替を想定した容量負荷で3コーナーを評価。最小セットアップ余裕+{d['setup_ns']:.2f} ns、ホールド余裕+{d['hold_ns']:.2f} ns。[負荷](../results/tile_loads.csv)・[低速](../results/readout/tile_sta_max.log)・[高速](../results/readout/tile_sta_min.log) |
| RTL・配線後ゲート | 各13,800クロック、70フレーム。両OSR、±30,720、リセット、Wrap、デバッグ分周を照合。[回帰試験](../results/readout/final_functional.txt) |
| アナログからSPIまで | 最終アナログ抽出波形の全30タップを32 MHzで配線後ゲートに再生。±0.20 Vで各3フレーム。第2・第3フレームは正側{code[1]:+d}、{code[2]:+d}、負側{code[4]:+d}、{code[5]:+d}。[SPI記録](../results/audited/final_spi.txt) |

## 直線性

入力コモンモード0.63 V、差動振幅±0.20 V、27 °C、標準バイアス。HD2・HD3は左右リングの周波数差に現れる高調波の基本波比である。静特性は11点の周波数差に5次チェビシェフ近似を適用した。動特性は50 kHz正弦波2周期の位相軌跡から求めた。SPIの出力コードを用いたFFTは実機の評価項目である。

| 最終アナログ抽出での条件 | HD2（上限−66 dBc） | HD3（上限−62 dBc） |
|---|---:|---:|
| TT・1.80 V 静的 | {d['HD_TT_static'][2]:.2f} dBc | {d['HD_TT_static'][3]:.2f} dBc |
| SS・1.62 V 静的 | {d['HD_SS_static'][2]:.2f} dBc | {d['HD_SS_static'][3]:.2f} dBc |
| TT・1.80 V 50 kHz | {d['HD_TT_50kHz'][2]:.2f} dBc | {d['HD_TT_50kHz'][3]:.2f} dBc |
| TT・1.80 V 50 kHz、外部タップ配線の抽出容量を追加 | {loaded[2]:.2f} dBc | {loaded[3]:.2f} dBc |

上3行は各受信端に5 fFを置いた共通条件。TTのHD3の静動差は{h[3]:.2f} dB（上限1 dB）。HD2の静動差は{h[2]:.2f} dBで、当初の4 dB目安を超えた。同じ静的11点でも7次近似のHD2は{d['HD2_degree7_TT_dBc']:.2f} dBcである。初回試作のHD2は静的・動的それぞれの振幅上限で判定し、推定手法間の一致度は実機評価に送った。

最下行には、アナログコアを除いた最終タイルから抽出した30タップの対地・相互容量も加えた。隣接端子を静止させたときのタップ別追加容量は{min(caps):.2f}〜{max(caps):.2f} fF。この条件のHD3余裕は{-62-loaded[3]:.2f} dB。[静的TT](../results/audited/final_tt.csv)・[静的SS](../results/audited/final_ss.csv)・[動的](../results/audited/final_dynamic.csv)・[配線負荷込み](../results/audited/final_loaded_dynamic.csv)

## 動作範囲と初回試作の評価項目

| 項目 | 確認できた範囲 |
|---|---|
| A0　単体リング | 単体リング抽出モデルのTT/SS/FF、−20/27/85 °C、6.5〜13.5 µAを各21点、計{d['PVT_points']}点で測定。電流・周波数曲線の近似は各組み合わせで個別に実施。[係数](../results/audited/a0_pvt_fit.csv) |
| A1　起動 | 標準条件の1 µs電源ランプで自律起動。無入力の平均発振周波数{d['zero_f0_MHz']:.3f} MHz、全段の最小差動振幅{float(zero['min_internal_diff_pp_V']):.3f} Vpp。1 msランプと実装基板の電源立上りは実機で評価する。 |
| A2・A3　速度 | SF・−20 °C・1.98 Vの低速バイアスで全タップが発振し、最低{d['slow_min_MHz']*1000:.2f} kHz、デューティ{float(slow['duty_min'])*100:.2f}〜{float(slow['duty_max'])*100:.2f}%。FF・85 °C・1.98 Vでは標準バイアス最高{d['fast_max_MHz']['nominal']:.3f} MHz（上限8.0）、高速バイアス最高{d['fast_max_MHz']['fast']:.3f} MHz（上限12.8）。高速の外部タップ配線容量込みは{float(extra['fmax30_MHz']):.3f} MHz。[低速](../results/audited/final_slow.csv)・[高速](../results/audited/final_loaded_fast.csv) |
| A5　雑音 | 20 MHz、OSR 128、−1 dBFS。入力段の入力換算45.33 µV rmsと仮定したリングFoMを使用し、9条件のモデルSNDRは{min(budget):.2f}〜{max(budget):.2f} dB。リングの素子雑音による1,000周期ジッタ、注入ロック、基板・電源帰還を含む実効SNDRは実機で評価する。[入力段雑音](../results/audited/front_noise.txt)・[条件別SNDR](../results/audited/final_noise_budget.csv) |
| A6　零点近傍 | TT、27 °C、タップ配線負荷込み。−10、−3、−1、0、+1、+3、+10 mVに対する周波数差は順に{', '.join(f'{measured[k]:+.3f}' for k in (-10,-3,-1,0,1,3,10))} kHz。±10 mVの極性を確認。1 mVの比例応答と連続する全振幅での分解能は実機で評価する。[配線負荷込み7点](../results/audited/final_loaded_small.csv)・[基準負荷5点](../results/audited/final_small.csv) |
| A7　ばらつき | PDKのTTミスマッチで抽出入力段を50回評価。共通の単体リングf(I)で換算した入力オフセット範囲は{min(offsets):+.2f}〜{max(offsets):+.2f} mV。電流がf(I)の実測範囲に収まった試行は{d['front_mismatch_in_range']}/50。左右リングを個別にばらつかせた全回路のHD2・3σ、歩留まりは未確定。[50試行](../results/audited/front_mismatch.csv) |

シリコンの初期条件は1.8 V、20 MHz、OSR 128、標準バイアス。各チップの零入力コードを測定し、そこからの±10 mVと±0.20 Vの変化、零点近傍のデッドゾーン、低歪み信号源でのHD3・SNDR、電源ランプ依存性の順に測定する。外部パッド、基板・パッケージの寄生、共通電源を経由する動的なデジタル帰還は測定系に依存する。[端子と測定手順](info.md)

製造検査PDKは `6d4d11780c40b20ee63cc98e645307a9bf2b2ab8`、ngspice用モデルは `8afc8346a57fe1ab7934ba5a6056ea8b43078e71`。アナログは最終レイアウトの素子と寄生容量を抽出し、全ネット対の容量をMagic EXTと照合した。コア内の金属配線は等電位とするモデルで、分布配線抵抗は含まない。[アナログLVS](../results/final_analog_lvs.txt)・[容量行列](../results/final_analog_matrix.csv)・[機械判定](../results/release_gate.json)
"""
    (ROOT/"docs/verification_status.md").write_text(body,encoding="utf-8")
if __name__=="__main__":main()

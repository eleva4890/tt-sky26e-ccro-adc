## How it works

This 1×2 SKY130A prototype uses two current-controlled 15-stage differential ring oscillators to convert a differential input voltage into a frequency difference. All 30 phase taps go through level shifters and two-flop synchronizers. On each sampling clock the readout counts phase transitions, subtracts the two counts, and decimates them with a signed 21-bit second-order CIC filter. The ADC sends one signed 16-bit word per decimation interval.

The final mask passed all 15 Tiny Tapeout prechecks. Full-tile LVS matched 10,390 devices and 5,137 nets. The nominal pre-silicon distortion targets are −66 dBc for HD2 and −62 dBc for HD3. Ring locking close to zero can reduce small-signal sensitivity. The prototype is intended for bench characterization of that region, SNDR and chip-to-chip variation.

## How to test

The design point under evaluation uses a 20 MHz sample clock, a 0.63 V input common-mode voltage and up to ±0.20 V differential input. For a differential voltage `d`, drive `ua[0] = 0.63 V + d/2` and `ua[1] = 0.63 V − d/2`. These are simulation conditions.

Set `ui_in = 0` for nominal bias, quiet debug outputs and OSR 128. Sample `uio[0]` MSB first on 16 rising edges of `uio[2]` while `uio[1]` is low. At 20 MHz the SPI clock is 5 MHz and the OSR-128 output rate is 156.25 kS/s. OSR 256 gives 78.125 kS/s. A positive input gives a positive settled code.

| Pins | Function |
|---|---|
| `ui_in[0]` | OSR select, 0 for 128 and 1 for 256 |
| `ui_in[2:1]` | 00 and 11 quiet, 01 raw P/N transition counts, 10 P/N oscillator frequencies divided by 64 |
| `ui_in[4:3]` | Bias select, 00 nominal, 01 slow, 10 intermediate, 11 fast |
| `ui_in[5]` | Synchronized active-high clear for the sticky wrap flag |
| `uo_out[7:0]` | In raw mode, P count in bits 7 to 4 and N count in bits 3 to 0. In divider mode, P on bit 0 and N on bit 1 |
| `uio[3:0]` | Sticky wrap flag, SPI clock, active-low chip select and serial data, in that order |

Keep the board's drivers on `uio[3:0]` in input mode. After reset or a change of OSR, discard the first two output frames. Measure the zero-input code on each die. Compare changes from that code at ±10 mV and ±0.20 V, then step through zero to measure the dead zone. The wrap flag records an observed transition count of 14 or 15. The RP2040 capture example in `tools/` has not been tested on silicon.

## External hardware

The evaluation setup in the supplied specification uses a differential signal source with controlled common mode, a Tiny Tapeout demo board and a logic analyzer or RP2040 PIO receiver.

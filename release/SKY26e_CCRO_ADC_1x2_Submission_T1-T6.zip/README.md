# SKY26e 差動VCOベースADC

SKY130Aの1×2タイルに、15段のクロスカップルリングを2本搭載した初回試作版。2本のアナログ入力を周波数差に変換し、30本の位相タップを読み取って、SPIに16ビット符号付きコードを出力する。公称電源1.8 V、入力共通電圧0.63 V、差動フルスケール±0.20 V、標準サンプルクロック20 MHz。

| データ | 内容 |
|---|---|
| [GDS](gds/tt_um_eleva_ccro_adc.gds)・[LEF](lef/tt_um_eleva_ccro_adc.lef)・[インターフェース](src/project.v) | 161.00 × 225.76 µm、53端子。使用するアナログ端子は2本。 |
| [アナログ抽出SPICE](layout/integration/final_analog_c.spice)・[トップ回路図](analog/top.spice) | スプリットテール入力、バイアス、発振器、CVSL、入力制御線のアンテナ保護。 |
| [読み出しRTL](rtl/adc_readout.v)・[配線後ゲート](layout/readout/adc_readout.nl.v) | 位相差分、21ビット2次CIC、OSR 128/256、SPI、デバッグ。 |
| [検証判定表](docs/verification_status.md)・[機械判定](results/release_gate.json) | 最終マスクの製造検査、電気性能、試作で検証する残項目。 |
| [端子・実機試験](docs/info.md)・[再現手順](verification/RELEASE.md) | 入力条件、SPIの読み出し、GDSの再生成、サインオフ、提出形式。 |

公式precheckは15/15合格。フルDRC違反0、アンテナ違反0、タイルLVSは10,390素子・5,137ネットが一意に一致した。HD3上限は−62 dBc。SNDRの実測保証、零点近傍の分解能、全回路のミスマッチ歩留まりは初回シリコンで評価する。[試作仕様](docs/01_SPEC.md)

リポジトリ直下の `.github/workflows/gds.yaml` はTiny TapeoutのSKY26e向けcustom GDSアクションを使用する。ZIPを展開すると、`info.yaml`、`gds/`、`lef/`、`src/` がリポジトリ直下にそろう。[公式アナログ仕様](https://tinytapeout.com/specs/analog/)

## 追加検証 T1〜T6

完全同相起動、電源変動、過入力、微小入力ロック、デジタル異常系の判定と試作時の動作制限を収録した。[追加検証結果](docs/torture_T1-T6.md)

仕様表、回路図、最終GDSのレイアウト図、波形と改版課題を収録した。[詳細設計レポート](docs/ccro_adc_design_report.pdf)
